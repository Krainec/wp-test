<?php return;
/**
 * This file exists soley to store the plugin
 * translation strings.
 *
 * It is never included anywhere, and is used for parsing.
 */

//
